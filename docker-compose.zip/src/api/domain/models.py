"""Domain entities - Pure business objects without framework dependencies"""
from abc import ABC
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Set
from uuid import UUID, uuid4

from api.domain.enums import (HttpMethod, InputType, ParamLocation, RuleType,
                              ScanStatus, ScopeAction, Severity)


@dataclass
class AbstractModel(ABC):
    """
    Base model, from which any domain model should be inherited.
    """

    async def to_dict(
            self,
            exclude: Optional[Set[str]] = None,
            include: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:

        """
        Create a dictionary representation of the model.

        exclude: set of model fields, which should be excluded from dictionary representation.
        include: set of model fields, which should be included into dictionary representation.
        """

        data: Dict[str, Any] = asdict(self)
        if exclude:
            for key in exclude:
                try:
                    del data[key]
                except KeyError:
                    pass

        if include:
            data.update(include)

        return data

@dataclass
class ProgramModel(AbstractModel):
    """Bug bounty program"""
    name: str
    id: UUID = field(default_factory=uuid4)

@dataclass
class ScopeRuleModel(AbstractModel):
    """Program scope rule"""
    program_id: UUID
    action: ScopeAction
    rule_type: RuleType
    pattern: str
    id: UUID = field(default_factory=uuid4)


@dataclass
class RootInputModel(AbstractModel):
    """Program root input (seed target)"""
    program_id: UUID
    value: str
    input_type: InputType
    id: UUID = field(default_factory=uuid4)


@dataclass
class HostModel(AbstractModel):
    """Discovered host/domain"""
    program_id: UUID
    host: str
    in_scope: bool = True
    cname: List[str] = field(default_factory=list)
    id: UUID = field(default_factory=uuid4)


@dataclass
class IPAddressModel(AbstractModel):
    """IP address"""
    program_id: UUID
    address: str
    in_scope: bool = True
    id: UUID = field(default_factory=uuid4)


@dataclass
class HostIPModel(AbstractModel):
    """Host to IP mapping"""
    host_id: UUID
    ip_id: UUID
    source: str  
    id: UUID = field(default_factory=uuid4)


@dataclass
class ServiceModel(AbstractModel):
    """Network service (HTTP/HTTPS endpoint)"""
    ip_id: UUID
    scheme: str
    port: int
    technologies: Dict[str, bool] = field(default_factory=dict)
    favicon_hash: str | None = None
    websocket: bool = False
    id: UUID = field(default_factory=uuid4)


@dataclass
class EndpointModel(AbstractModel):
    """HTTP endpoint"""
    host_id: UUID
    service_id: UUID
    path: str
    normalized_path: str
    methods: List[HttpMethod] = field(default_factory=list)  
    status_code: Optional[int] = None
    id: UUID = field(default_factory=uuid4)



@dataclass
class InputParameterModel(AbstractModel):
    """Input parameter (query/body/header)"""
    endpoint_id: UUID
    name: str
    location: ParamLocation
    service_id: UUID
    param_type: str = "string"  
    reflected: bool = False
    is_array: bool = False
    example_value: Optional[str] = None
    id: UUID = field(default_factory=uuid4)
    


@dataclass
class HeaderModel(AbstractModel):
    """HTTP response header"""
    endpoint_id: UUID
    name: str
    value: str
    id: UUID = field(default_factory=uuid4)


@dataclass
class RawBodyModel(AbstractModel):
    """Raw HTTP request body"""
    endpoint_id: UUID
    body_content: str
    body_hash: str
    id: UUID = field(default_factory=uuid4)


@dataclass
class HTTPObservationModel(AbstractModel):
    """One HTTP response observation captured during a scan run."""
    program_id: UUID
    endpoint_id: UUID
    service_id: UUID
    method: str
    url: str
    source_tool: str
    job_id: Optional[UUID] = None
    run_id: Optional[UUID] = None
    correlation_id: Optional[UUID] = None
    raw_artifact_id: Optional[UUID] = None
    status_code: Optional[int] = None
    content_type: Optional[str] = None
    title: Optional[str] = None
    body_sha256: Optional[str] = None
    body_size_bytes: Optional[int] = None
    body_artifact_id: Optional[UUID] = None
    body_preview: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    observed_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    id: UUID = field(default_factory=uuid4)


@dataclass
class HTTPObservationHeaderModel(AbstractModel):
    """HTTP header value attached to a specific HTTP observation."""
    observation_id: UUID
    name: str
    value: str
    ordinal: int = 0
    id: UUID = field(default_factory=uuid4)


@dataclass
class JavaScriptReferenceModel(AbstractModel):
    """Endpoint reference extracted from a JavaScript source."""
    program_id: UUID
    endpoint_id: UUID
    service_id: UUID
    source_url: str
    referenced_url: str
    source_tool: str
    reference_type: str = "endpoint"
    job_id: Optional[UUID] = None
    run_id: Optional[UUID] = None
    correlation_id: Optional[UUID] = None
    raw_artifact_id: Optional[UUID] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    observed_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    id: UUID = field(default_factory=uuid4)


@dataclass
class VulnTypeModel(AbstractModel):
    """Vulnerability type definition"""
    code: str
    severity: Severity
    category: str
    id: UUID = field(default_factory=uuid4)



@dataclass
class ScannerTemplateModel(AbstractModel):
    """Scanner configuration template"""
    name: str
    tool: str
    command_template: str
    category: str
    enabled: bool = True
    id: UUID = field(default_factory=uuid4)

@dataclass
class ScannerExecutionModel(AbstractModel):
    """Scan execution record"""
    program_id: UUID
    status: ScanStatus
    template_id: Optional[UUID]
    endpoint_id: UUID
    error_message: Optional[str] = None
    id: UUID = field(default_factory=uuid4)

@dataclass
class PayloadModel(AbstractModel):
    """Attack payload"""
    vuln_type_id: UUID
    payload: str
    description: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    id: UUID = field(default_factory=uuid4)

@dataclass
class FindingModel(AbstractModel):
    """Vulnerability finding"""
    program_id: UUID
    vuln_type_id: UUID
    description: str
    host_id: Optional[UUID] = None
    endpoint_id: Optional[UUID] = None
    parameter_id: Optional[UUID] = None
    payload_id: Optional[UUID] = None
    execution_id: Optional[UUID] = None
    evidence: Dict[str, Any] = field(default_factory=dict)
    verified: bool = False
    false_positive: bool = False
    id: UUID = field(default_factory=uuid4)


@dataclass
class LeakModel(AbstractModel):
    """Information leak"""
    program_id: UUID
    endpoint_id: Optional[UUID]
    content: str
    verified: bool = False
    false_positive: bool = False
    id: UUID = field(default_factory=uuid4)


@dataclass
class DNSRecordModel(AbstractModel):
    """DNS record"""
    host_id: UUID
    record_type: str
    value: str
    ttl: Optional[int] = None
    priority: Optional[int] = None
    is_wildcard: bool = False
    id: UUID = field(default_factory=uuid4)


@dataclass
class OrganizationModel(AbstractModel):
    """Organization/Company"""
    program_id: UUID
    name: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    id: UUID = field(default_factory=uuid4)


@dataclass
class ASNModel(AbstractModel):
    """Autonomous System Number"""
    program_id: UUID
    asn_number: int
    organization_name: str
    country_code: Optional[str] = None
    description: Optional[str] = None
    organization_id: Optional[UUID] = None
    id: UUID = field(default_factory=uuid4)


@dataclass
class CIDRModel(AbstractModel):
    """CIDR IP range"""
    program_id: UUID
    cidr: str
    asn_id: Optional[UUID] = None
    ip_count: Optional[int] = None
    expanded: bool = False
    in_scope: bool = True
    id: UUID = field(default_factory=uuid4)
