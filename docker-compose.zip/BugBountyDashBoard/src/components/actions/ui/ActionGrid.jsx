export default function ActionGrid({ children }) {
  return (
    <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
      {children}
    </div>
  )
}
