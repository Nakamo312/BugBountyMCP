import { useProgram } from '../context/ProgramContext'
import { Server, Loader, AlertCircle } from 'lucide-react'
import useHosts from '../hooks/useHosts'
import {
  HostCard,
  HostFilters,
  HostStats,
  EndpointCard,
  EndpointDetails,
  Pagination,
} from '../components/hosts'

const Hosts = () => {
  const { selectedProgram } = useProgram()
  const {
    hosts,
    allHosts,
    programStats,
    loading,
    inScopeFilter,
    setInScopeFilter,
    serviceFilter,
    setServiceFilter,
    techFilter,
    setTechFilter,
    sortBy,
    setSortBy,
    searchTerm,
    setSearchTerm,
    availableServices,
    availableTechs,
    expandedHosts,
    expandedEndpoints,
    endpointDetails,
    loadingDetails,
    pagination,
    toggleHost,
    toggleEndpoint,
    loadEndpointDetails,
    handlePageChange,
    clearFilters,
    refresh,
  } = useHosts(selectedProgram)

  if (!selectedProgram) {
    return (
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
        <div className="flex items-center space-x-3">
          <AlertCircle className="text-yellow-600" size={24} />
          <div>
            <h3 className="font-semibold text-yellow-900">No Program Selected</h3>
            <p className="text-sm text-yellow-700 mt-1">
              Please select a program from the sidebar to view hosts.
            </p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Hosts</h1>
        <p className="text-gray-600 mt-2">
          View hosts and endpoints for program:{' '}
          <span className="font-semibold text-primary-600">{selectedProgram.name}</span>
        </p>
      </div>

      <HostFilters
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        inScopeFilter={inScopeFilter}
        onFilterChange={setInScopeFilter}
        serviceFilter={serviceFilter}
        onServiceFilterChange={setServiceFilter}
        techFilter={techFilter}
        onTechFilterChange={setTechFilter}
        sortBy={sortBy}
        onSortChange={setSortBy}
        availableServices={availableServices}
        availableTechs={availableTechs}
        onRefresh={refresh}
        loading={loading}
        onClearFilters={clearFilters}
      />

      <HostStats programStats={programStats} hosts={allHosts} filteredCount={hosts.length} />

      {loading && hosts.length === 0 ? (
        <div className="flex items-center justify-center h-64">
          <Loader className="animate-spin text-primary-500" size={32} />
        </div>
      ) : hosts.length === 0 ? (
        <div className="bg-gray-50 border-2 border-dashed border-gray-300 rounded-lg p-12 text-center">
          <Server className="mx-auto text-gray-400" size={48} />
          <h3 className="mt-4 text-lg font-medium text-gray-900">No hosts found</h3>
          <p className="mt-2 text-sm text-gray-600">
            {searchTerm ? 'Try adjusting your search terms' : 'No hosts available for this program'}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {hosts.map((host) => {
            const isExpanded = expandedHosts.has(host.id)
            const endpoints = endpointDetails[host.id] || []

            return (
              <HostCard
                key={host.id}
                host={host}
                isExpanded={isExpanded}
                onToggle={() => toggleHost(host.id)}
              >
                {isExpanded && endpoints.length > 0 && (
                  <div className="border-t border-gray-200 p-4 space-y-2">
                    {endpoints.map((endpoint) => {
                      const isEndpointExpanded = expandedEndpoints.has(endpoint.id)
                      const details = endpointDetails[endpoint.id]
                      const isLoadingDetails = loadingDetails.has(endpoint.id)

                      return (
                        <EndpointCard
                          key={endpoint.id}
                          endpoint={endpoint}
                          isExpanded={isEndpointExpanded}
                          onToggle={() => toggleEndpoint(endpoint.id)}
                        >
                          <EndpointDetails
                            endpoint={endpoint}
                            details={details}
                            isLoading={isLoadingDetails}
                            onLoadDetails={loadEndpointDetails}
                          />
                        </EndpointCard>
                      )
                    })}
                  </div>
                )}

                {isExpanded && endpoints.length === 0 && (
                  <div className="border-t border-gray-200 p-4 text-center text-sm text-gray-500">
                    No endpoints found for this host
                  </div>
                )}
              </HostCard>
            )
          })}
        </div>
      )}

      <Pagination pagination={pagination} onPageChange={handlePageChange} />
    </div>
  )
}

export default Hosts
