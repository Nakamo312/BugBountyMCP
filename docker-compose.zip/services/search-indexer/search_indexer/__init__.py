"""Standalone OpenSearch indexing service."""

